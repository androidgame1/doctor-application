<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PurchaseInvoiceLineController extends Controller
{
    //
}
