<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SaleInvoiceLineController extends Controller
{
    //
}
