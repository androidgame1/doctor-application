<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JBqtmxfKn4V31JxE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PUW5iPh3PFRvbXr8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jwM3j9La6wIocLrq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4W2UZgUDSascUWfH',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::08rG17kfpsaduHQG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/reset' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/password/confirm' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BqK785TGnZyfp9gD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/forget-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'forget.password.get',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'forget.password.post',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reset.password.post',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/superadministrator/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'superadministrator.home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/superadministrator/edit-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'superadministrator.password.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/superadministrator/update-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'superadministrator.password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/superadministrator/edit-profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'superadministrator.profile.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/superadministrator/update-profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'superadministrator.profile.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.home.filter',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/home/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.home.report',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/edit-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.password.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/update-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/edit-profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.profile.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/update-profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.profile.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/suppliers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.suppliers',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/supplier/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.supplier.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/supplier/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.supplier.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.products',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/product/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.product.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/acts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.acts',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/act/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.act.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/purchase_invoices' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoices',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoices.dates.filter',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/purchase_invoice/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/purchase_invoice/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/purchase_invoice_payment/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice_payment.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/sale_invoices' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoices',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoices.dates.filter',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/sale_invoice/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/sale_invoice/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/sale_invoice_payment/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice_payment.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/activities' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activities',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activities.dates.filter',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/activity/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/activity/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/quotes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.quotes',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.quotes.dates.filter',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/quote/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.quote.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/quote/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.quote.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/activity_payment/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity_payment.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/delivery_orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.delivery_orders',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/delivery_order/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.delivery_order.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/delivery_order/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.delivery_order.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/purchase_orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_orders',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/purchase_order/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_order.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/purchase_order/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_order.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/patients' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.patients',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/patient/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.patient.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/patient/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.patient.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/calendar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.calendar',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/appointment/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.appointment.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/appointment/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.appointment.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.status',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/status/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.status.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/drugs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.drugs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/drug/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.drug.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/tests' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.tests',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/test/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.test.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/type_drugs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.type_drugs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/type_drug/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.type_drug.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/prescriptions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.prescriptions',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/prescription/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.prescription.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/prescription/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.prescription.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/charges' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.charges',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.charges.dates.filter',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/administrator/charge/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.charge.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/secretary/home' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/secretary/edit-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.password.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/secretary/update-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/secretary/edit-profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.profile.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/secretary/update-profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.profile.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/secretary/patients' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.patients',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/secretary/patient/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.patient.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/secretary/patient/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.patient.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/secretary/calendar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.calendar',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/secretary/appointment/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.appointment.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/secretary/appointment/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.appointment.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/change\\-languge/([^/]++)(*:32)|/password/reset/([^/]++)(*:63)|/reset\\-password/([^/]++)/([^/]++)(*:104)|/s(?|uperadministrator/user(?|s/([^/]++)(*:152)|/([^/]++)/(?|([^/]++)/show(*:186)|create(*:200)|store(*:213)|([^/]++)/(?|edit(*:237)|update(*:251)|destroy(*:266)|status/update(*:287))))|ecretary/(?|patient/([^/]++)/(?|show(*:334)|edit(*:346)|update(*:360)|destroy(*:375))|appointment(?|s/([^/]++)(*:408)|/([^/]++)/(?|show(*:433)|edit(*:445)|update(*:459)|d(?|estroy(*:477)|rop\\-or\\-resize(*:500))))))|/administrator/(?|user(?|s/([^/]++)(?|(*:551)|/([^/]++)(*:568))|/([^/]++)/(?|([^/]++)/show(*:603)|create(*:617)|store(*:630)|([^/]++)/(?|edit(*:654)|update(*:668)|destroy(*:683)|status/update(*:704))))|s(?|upplier/([^/]++)/(?|show(*:743)|edit(*:755)|update(*:769)|destroy(*:784))|ale_invoice(?|s/([^/]++)/filter(*:824)|/([^/]++)/(?|show(*:849)|edit(*:861)|update(*:875)|d(?|estroy(*:893)|uplicate(*:909))|cancel(*:924)|pdf(*:935))|_payment(?|s/([^/]++)(*:965)|/([^/]++)/(?|show(*:990)|create(*:1004)|edit(*:1017)|update(*:1032)|destroy(*:1048))))|tatus/([^/]++)/(?|show(*:1082)|edit(*:1095)|update(*:1110)|destroy(*:1126)))|p(?|r(?|oduct/([^/]++)/(?|show(*:1167)|edit(*:1180)|update(*:1195)|destroy(*:1211))|escription/([^/]++)/(?|show(*:1248)|edit(*:1261)|update(*:1276)|destroy(*:1292)|pdf(*:1304)))|urchase(?|_(?|invoice(?|s/([^/]++)/filter(*:1356)|/([^/]++)/(?|show(*:1382)|edit(*:1395)|update(*:1410)|d(?|estroy(*:1429)|uplicate(*:1446))|cancel(*:1462)|pdf(*:1474))|_payment(?|s/([^/]++)(*:1505)|/([^/]++)/(?|show(*:1531)|create(*:1546)|edit(*:1559)|update(*:1574)|destroy(*:1590))))|order/([^/]++)/(?|show(*:1624)|edit(*:1637)|update(*:1652)|destroy(*:1668)|pdf(*:1680)))|\\-order\\-to\\-delivery\\-order/([^/]++)/convert(*:1736))|atient/([^/]++)/(?|show(*:1769)|edit(*:1782)|update(*:1797)|destroy(*:1813)))|a(?|ct(?|/([^/]++)/(?|show(*:1850)|edit(*:1863)|update(*:1878)|destroy(*:1894))|ivit(?|ies/([^/]++)/filter(*:1930)|y(?|/([^/]++)/(?|show(*:1960)|edit(*:1973)|update(*:1988)|d(?|estroy(*:2007)|uplicate(*:2024))|cancel(*:2040)|pdf(*:2052))|_payment(?|s/([^/]++)(*:2083)|/([^/]++)/(?|show(*:2109)|create(*:2124)|edit(*:2137)|update(*:2152)|destroy(*:2168))))))|ppointment(?|s/([^/]++)(?|(*:2208))|/([^/]++)/(?|show(*:2235)|edit(*:2248)|update(*:2263)|d(?|estroy(*:2282)|rop\\-or\\-resize(*:2306)))))|quote(?|s/([^/]++)/filter(*:2344)|/([^/]++)/(?|show(*:2370)|edit(*:2383)|update(*:2398)|d(?|estroy(*:2417)|uplicate(*:2434))|cancel(*:2450)|pdf(*:2462)))|d(?|elivery_order(?|s/([^/]++)/purchase_order(*:2518)|/([^/]++)/(?|show(*:2544)|edit(*:2557)|update(*:2572)|d(?|estroy(*:2591)|uplicate(*:2608))))|rug/([^/]++)/(?|show(*:2640)|edit(*:2653)|update(*:2668)|destroy(*:2684)))|t(?|est/([^/]++)/(?|show(*:2719)|edit(*:2732)|update(*:2747)|destroy(*:2763))|ype_drug/([^/]++)/(?|show(*:2798)|edit(*:2811)|update(*:2826)|destroy(*:2842)))|charge(?|s/([^/]++)/secretary(?|(*:2885))|/([^/]++)/(?|show(*:2912)|edit(*:2925)|update(*:2940)|destroy(*:2956))))|/(.*)(*:2973))/?$}sDu',
    ),
    3 => 
    array (
      32 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'change.language',
          ),
          1 => 
          array (
            0 => 'lang',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      63 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      104 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reset.password.get',
          ),
          1 => 
          array (
            0 => 'token',
            1 => 'email',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      152 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'superadministrator.users',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      186 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'superadministrator.user.show',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      200 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'superadministrator.user.create',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      213 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'superadministrator.user.store',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      237 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'superadministrator.user.edit',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      251 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'superadministrator.user.update',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      266 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'superadministrator.user.destroy',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      287 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'superadministrator.user.status.update',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      334 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.patient.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      346 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.patient.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      360 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.patient.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      375 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.patient.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      408 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.appointments',
          ),
          1 => 
          array (
            0 => 'from',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      433 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.appointment.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      445 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.appointment.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      459 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.appointment.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      477 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.appointment.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      500 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'secretary.appointment.drop_or_resize',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      551 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.users',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      568 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.users.filter',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'validation',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      603 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.user.show',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      617 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.user.create',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      630 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.user.store',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      654 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.user.edit',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      668 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.user.update',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      683 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.user.destroy',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      704 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.user.status.update',
          ),
          1 => 
          array (
            0 => 'role',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      743 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.supplier.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      755 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.supplier.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      769 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.supplier.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      784 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.supplier.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      824 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoices.filter',
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      849 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      861 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      875 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      893 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      909 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice.duplicate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      924 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice.cancel',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      935 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice.pdf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      965 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice_payments',
          ),
          1 => 
          array (
            0 => 'sale_invoice_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      990 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice_payment.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1004 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice_payment.create',
          ),
          1 => 
          array (
            0 => 'sale_invoice_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1017 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice_payment.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1032 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice_payment.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1048 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.sale_invoice_payment.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1082 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.status.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1095 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.status.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1110 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.status.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1126 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.status.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1167 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.product.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1180 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.product.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1195 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.product.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1211 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.product.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1248 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.prescription.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1261 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.prescription.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1276 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.prescription.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1292 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.prescription.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1304 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.prescription.pdf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1356 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoices.filter',
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1382 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1395 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1410 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1429 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1446 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice.duplicate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1462 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice.cancel',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1474 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice.pdf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1505 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice_payments',
          ),
          1 => 
          array (
            0 => 'purchase_invoice_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1531 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice_payment.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1546 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice_payment.create',
          ),
          1 => 
          array (
            0 => 'purchase_invoice_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1559 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice_payment.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1574 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice_payment.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1590 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_invoice_payment.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1624 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_order.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1637 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_order.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1652 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_order.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1668 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_order.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1680 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.purchase_order.pdf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1736 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.delivery_order.convert_po_to_do',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1769 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.patient.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1782 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.patient.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1797 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.patient.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1813 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.patient.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1850 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.act.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1863 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.act.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1878 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.act.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1894 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.act.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1930 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activities.filter',
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1960 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1973 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1988 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2007 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2024 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity.duplicate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2040 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity.cancel',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2052 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity.pdf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2083 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity_payments',
          ),
          1 => 
          array (
            0 => 'activity_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2109 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity_payment.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2124 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity_payment.create',
          ),
          1 => 
          array (
            0 => 'activity_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2137 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity_payment.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2152 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity_payment.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2168 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.activity_payment.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2208 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.appointments',
          ),
          1 => 
          array (
            0 => 'from',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.appointments.dates.filter',
          ),
          1 => 
          array (
            0 => 'from',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2235 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.appointment.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2248 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.appointment.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2263 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.appointment.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2282 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.appointment.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2306 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.appointment.drop_or_resize',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2344 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.quotes.filter',
          ),
          1 => 
          array (
            0 => 'status',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2370 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.quote.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2383 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.quote.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2398 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.quote.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2417 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.quote.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2434 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.quote.duplicate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2450 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.quote.cancel',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2462 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.quote.pdf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2518 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.delivery_orders.purchase_order',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2544 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.delivery_order.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2557 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.delivery_order.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2572 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.delivery_order.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2591 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.delivery_order.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2608 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.delivery_order.duplicate',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2640 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.drug.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2653 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.drug.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2668 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.drug.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2684 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.drug.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2719 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.test.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2732 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.test.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2747 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.test.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2763 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.test.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2798 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.type_drug.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2811 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.type_drug.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2826 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.type_drug.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2842 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.type_drug.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2885 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.charges.secretary',
          ),
          1 => 
          array (
            0 => 'secretary_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.charges.secretary.dates.filter',
          ),
          1 => 
          array (
            0 => 'secretary_id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2912 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.charge.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2925 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.charge.edit',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2940 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.charge.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2956 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'administrator.charge.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2973 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uCSxDadXDsoA56wj',
          ),
          1 => 
          array (
            0 => 'fallbackPlaceholder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::JBqtmxfKn4V31JxE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::JBqtmxfKn4V31JxE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PUW5iPh3PFRvbXr8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000058ad94b0000000005b730e1b";}";s:4:"hash";s:44:"Z6fxzFTvBQriAz30aE9Kz6jPmLz738ftCZ7g5k8qKgI=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::PUW5iPh3PFRvbXr8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jwM3j9La6wIocLrq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:281:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:63:"function () {
        return \\redirect()->route(\'login\');
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000058ad94b7000000005b730e1b";}";s:4:"hash";s:44:"jiXLyz/h7H9DdpSjdcSgRUO0yIAzwcoX1Ly75NINSno=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jwM3j9La6wIocLrq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'change.language' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'change-languge/{lang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@changeLanguage',
        'controller' => 'App\\Http\\Controllers\\HomeController@changeLanguage',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'change.language',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@showLoginForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4W2UZgUDSascUWfH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::4W2UZgUDSascUWfH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@showRegistrationForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::08rG17kfpsaduHQG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::08rG17kfpsaduHQG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showLinkRequestForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/reset/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@showResetForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.confirm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@showConfirmForm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.confirm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BqK785TGnZyfp9gD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'password/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ConfirmPasswordController@confirm',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BqK785TGnZyfp9gD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'forget.password.get' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'forget-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showForgetPasswordForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showForgetPasswordForm',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'forget.password.get',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'forget.password.post' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'forget-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@submitForgetPasswordForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@submitForgetPasswordForm',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'forget.password.post',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reset.password.get' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reset-password/{token}/{email}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showResetPasswordForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@showResetPasswordForm',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'reset.password.get',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reset.password.post' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@submitResetPasswordForm',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@submitResetPasswordForm',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'reset.password.post',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'superadministrator.home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'superadministrator/home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.superadministrator',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\HomeController@index',
        'namespace' => NULL,
        'prefix' => '/superadministrator',
        'where' => 
        array (
        ),
        'as' => 'superadministrator.home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'superadministrator.password.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'superadministrator/edit-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.superadministrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@editPassword',
        'controller' => 'App\\Http\\Controllers\\UserController@editPassword',
        'namespace' => NULL,
        'prefix' => '/superadministrator',
        'where' => 
        array (
        ),
        'as' => 'superadministrator.password.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'superadministrator.password.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'superadministrator/update-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.superadministrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@updatePassword',
        'controller' => 'App\\Http\\Controllers\\UserController@updatePassword',
        'namespace' => NULL,
        'prefix' => '/superadministrator',
        'where' => 
        array (
        ),
        'as' => 'superadministrator.password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'superadministrator.profile.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'superadministrator/edit-profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.superadministrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@editProfile',
        'controller' => 'App\\Http\\Controllers\\UserController@editProfile',
        'namespace' => NULL,
        'prefix' => '/superadministrator',
        'where' => 
        array (
        ),
        'as' => 'superadministrator.profile.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'superadministrator.profile.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'superadministrator/update-profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.superadministrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@updateProfile',
        'controller' => 'App\\Http\\Controllers\\UserController@updateProfile',
        'namespace' => NULL,
        'prefix' => '/superadministrator',
        'where' => 
        array (
        ),
        'as' => 'superadministrator.profile.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'superadministrator.users' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'superadministrator/users/{role}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.superadministrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\UserController@index',
        'namespace' => NULL,
        'prefix' => '/superadministrator',
        'where' => 
        array (
        ),
        'as' => 'superadministrator.users',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'superadministrator.user.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'superadministrator/user/{role}/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.superadministrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@show',
        'controller' => 'App\\Http\\Controllers\\UserController@show',
        'namespace' => NULL,
        'prefix' => '/superadministrator',
        'where' => 
        array (
        ),
        'as' => 'superadministrator.user.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'superadministrator.user.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'superadministrator/user/{role}/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.superadministrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create',
        'controller' => 'App\\Http\\Controllers\\UserController@create',
        'namespace' => NULL,
        'prefix' => '/superadministrator',
        'where' => 
        array (
        ),
        'as' => 'superadministrator.user.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'superadministrator.user.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'superadministrator/user/{role}/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.superadministrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\UserController@store',
        'namespace' => NULL,
        'prefix' => '/superadministrator',
        'where' => 
        array (
        ),
        'as' => 'superadministrator.user.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'superadministrator.user.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'superadministrator/user/{role}/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.superadministrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\UserController@edit',
        'namespace' => NULL,
        'prefix' => '/superadministrator',
        'where' => 
        array (
        ),
        'as' => 'superadministrator.user.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'superadministrator.user.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'superadministrator/user/{role}/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.superadministrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => NULL,
        'prefix' => '/superadministrator',
        'where' => 
        array (
        ),
        'as' => 'superadministrator.user.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'superadministrator.user.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'superadministrator/user/{role}/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.superadministrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\UserController@destroy',
        'namespace' => NULL,
        'prefix' => '/superadministrator',
        'where' => 
        array (
        ),
        'as' => 'superadministrator.user.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'superadministrator.user.status.update' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'superadministrator/user/{role}/{id}/status/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.superadministrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\UserController@updateStatus',
        'namespace' => NULL,
        'prefix' => '/superadministrator',
        'where' => 
        array (
        ),
        'as' => 'superadministrator.user.status.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\HomeController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.home.filter' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\HomeController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.home.filter',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.home.report' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/home/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@report',
        'controller' => 'App\\Http\\Controllers\\HomeController@report',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.home.report',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.password.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/edit-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@editPassword',
        'controller' => 'App\\Http\\Controllers\\UserController@editPassword',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.password.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.password.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/update-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@updatePassword',
        'controller' => 'App\\Http\\Controllers\\UserController@updatePassword',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.profile.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/edit-profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@editProfile',
        'controller' => 'App\\Http\\Controllers\\UserController@editProfile',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.profile.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.profile.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/update-profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@updateProfile',
        'controller' => 'App\\Http\\Controllers\\UserController@updateProfile',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.profile.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.users' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/users/{role}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\UserController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.users',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.users.filter' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/users/{role}/{validation}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@filter',
        'controller' => 'App\\Http\\Controllers\\UserController@filter',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.users.filter',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.user.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/user/{role}/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@show',
        'controller' => 'App\\Http\\Controllers\\UserController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.user.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.user.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/user/{role}/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create',
        'controller' => 'App\\Http\\Controllers\\UserController@create',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.user.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.user.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/user/{role}/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\UserController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.user.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.user.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/user/{role}/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\UserController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.user.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.user.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/user/{role}/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.user.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.user.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/user/{role}/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\UserController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.user.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.user.status.update' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/user/{role}/{id}/status/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\UserController@updateStatus',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.user.status.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.suppliers' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/suppliers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@index',
        'controller' => 'App\\Http\\Controllers\\SupplierController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.suppliers',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.supplier.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/supplier/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@show',
        'controller' => 'App\\Http\\Controllers\\SupplierController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.supplier.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.supplier.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/supplier/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@create',
        'controller' => 'App\\Http\\Controllers\\SupplierController@create',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.supplier.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.supplier.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/supplier/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@store',
        'controller' => 'App\\Http\\Controllers\\SupplierController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.supplier.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.supplier.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/supplier/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@edit',
        'controller' => 'App\\Http\\Controllers\\SupplierController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.supplier.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.supplier.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/supplier/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@update',
        'controller' => 'App\\Http\\Controllers\\SupplierController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.supplier.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.supplier.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/supplier/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@destroy',
        'controller' => 'App\\Http\\Controllers\\SupplierController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.supplier.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.products' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@index',
        'controller' => 'App\\Http\\Controllers\\ProductController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.products',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.product.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/product/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@show',
        'controller' => 'App\\Http\\Controllers\\ProductController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.product.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.product.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/product/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@store',
        'controller' => 'App\\Http\\Controllers\\ProductController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.product.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.product.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/product/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@edit',
        'controller' => 'App\\Http\\Controllers\\ProductController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.product.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.product.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/product/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update',
        'controller' => 'App\\Http\\Controllers\\ProductController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.product.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.product.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/product/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@destroy',
        'controller' => 'App\\Http\\Controllers\\ProductController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.product.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.acts' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/acts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActController@index',
        'controller' => 'App\\Http\\Controllers\\ActController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.acts',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.act.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/act/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActController@show',
        'controller' => 'App\\Http\\Controllers\\ActController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.act.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.act.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/act/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActController@store',
        'controller' => 'App\\Http\\Controllers\\ActController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.act.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.act.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/act/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActController@edit',
        'controller' => 'App\\Http\\Controllers\\ActController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.act.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.act.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/act/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActController@update',
        'controller' => 'App\\Http\\Controllers\\ActController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.act.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.act.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/act/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActController@destroy',
        'controller' => 'App\\Http\\Controllers\\ActController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.act.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoices' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@index',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoices',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoices.dates.filter' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/purchase_invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@index',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoices.dates.filter',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoices.filter' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_invoices/{status}/filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@filter',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@filter',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoices.filter',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_invoice/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@show',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_invoice/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@create',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@create',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/purchase_invoice/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@store',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_invoice/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@edit',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/purchase_invoice/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@update',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/purchase_invoice/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@destroy',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice.cancel' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_invoice/{id}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@cancel',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@cancel',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice.cancel',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice.duplicate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_invoice/{id}/duplicate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@duplicate',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@duplicate',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice.duplicate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice.pdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_invoice/{id}/pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoiceController@pdf',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoiceController@pdf',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice.pdf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice_payments' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_invoice_payments/{purchase_invoice_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoicePaymentController@index',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoicePaymentController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice_payments',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice_payment.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_invoice_payment/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoicePaymentController@show',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoicePaymentController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice_payment.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice_payment.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_invoice_payment/{purchase_invoice_id}/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoicePaymentController@create',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoicePaymentController@create',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice_payment.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice_payment.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/purchase_invoice_payment/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoicePaymentController@store',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoicePaymentController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice_payment.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice_payment.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_invoice_payment/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\ControllePurchase@edit',
        'controller' => 'App\\Http\\ControllePurchase@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice_payment.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice_payment.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/purchase_invoice_payment/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoicePaymentController@update',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoicePaymentController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice_payment.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_invoice_payment.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/purchase_invoice_payment/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseInvoicePaymentController@destroy',
        'controller' => 'App\\Http\\Controllers\\PurchaseInvoicePaymentController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_invoice_payment.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoices' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/sale_invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@index',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoices',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoices.dates.filter' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/sale_invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@index',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoices.dates.filter',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoices.filter' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/sale_invoices/{status}/filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@filter',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@filter',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoices.filter',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/sale_invoice/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@show',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/sale_invoice/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@create',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@create',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/sale_invoice/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@store',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/sale_invoice/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@edit',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/sale_invoice/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@update',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/sale_invoice/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@destroy',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice.cancel' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/sale_invoice/{id}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@cancel',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@cancel',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice.cancel',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice.duplicate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/sale_invoice/{id}/duplicate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@duplicate',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@duplicate',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice.duplicate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice.pdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/sale_invoice/{id}/pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoiceController@pdf',
        'controller' => 'App\\Http\\Controllers\\SaleInvoiceController@pdf',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice.pdf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice_payments' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/sale_invoice_payments/{sale_invoice_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoicePaymentController@index',
        'controller' => 'App\\Http\\Controllers\\SaleInvoicePaymentController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice_payments',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice_payment.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/sale_invoice_payment/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoicePaymentController@show',
        'controller' => 'App\\Http\\Controllers\\SaleInvoicePaymentController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice_payment.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice_payment.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/sale_invoice_payment/{sale_invoice_id}/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoicePaymentController@create',
        'controller' => 'App\\Http\\Controllers\\SaleInvoicePaymentController@create',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice_payment.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice_payment.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/sale_invoice_payment/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoicePaymentController@store',
        'controller' => 'App\\Http\\Controllers\\SaleInvoicePaymentController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice_payment.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice_payment.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/sale_invoice_payment/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoicePaymentController@edit',
        'controller' => 'App\\Http\\Controllers\\SaleInvoicePaymentController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice_payment.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice_payment.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/sale_invoice_payment/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoicePaymentController@update',
        'controller' => 'App\\Http\\Controllers\\SaleInvoicePaymentController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice_payment.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.sale_invoice_payment.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/sale_invoice_payment/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleInvoicePaymentController@destroy',
        'controller' => 'App\\Http\\Controllers\\SaleInvoicePaymentController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.sale_invoice_payment.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activities' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/activities',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityController@index',
        'controller' => 'App\\Http\\Controllers\\ActivityController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activities',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activities.dates.filter' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/activities',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityController@index',
        'controller' => 'App\\Http\\Controllers\\ActivityController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activities.dates.filter',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activities.filter' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/activities/{status}/filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityController@filter',
        'controller' => 'App\\Http\\Controllers\\ActivityController@filter',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activities.filter',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/activity/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityController@show',
        'controller' => 'App\\Http\\Controllers\\ActivityController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/activity/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityController@create',
        'controller' => 'App\\Http\\Controllers\\ActivityController@create',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/activity/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityController@store',
        'controller' => 'App\\Http\\Controllers\\ActivityController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/activity/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityController@edit',
        'controller' => 'App\\Http\\Controllers\\ActivityController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/activity/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityController@update',
        'controller' => 'App\\Http\\Controllers\\ActivityController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/activity/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityController@destroy',
        'controller' => 'App\\Http\\Controllers\\ActivityController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity.cancel' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/activity/{id}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityController@cancel',
        'controller' => 'App\\Http\\Controllers\\ActivityController@cancel',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity.cancel',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity.duplicate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/activity/{id}/duplicate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityController@duplicate',
        'controller' => 'App\\Http\\Controllers\\ActivityController@duplicate',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity.duplicate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity.pdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/activity/{id}/pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityController@pdf',
        'controller' => 'App\\Http\\Controllers\\ActivityController@pdf',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity.pdf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.quotes' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/quotes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\QuoteController@index',
        'controller' => 'App\\Http\\Controllers\\QuoteController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.quotes',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.quotes.dates.filter' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/quotes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\QuoteController@index',
        'controller' => 'App\\Http\\Controllers\\QuoteController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.quotes.dates.filter',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.quotes.filter' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/quotes/{status}/filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\QuoteController@filter',
        'controller' => 'App\\Http\\Controllers\\QuoteController@filter',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.quotes.filter',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.quote.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/quote/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\QuoteController@show',
        'controller' => 'App\\Http\\Controllers\\QuoteController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.quote.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.quote.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/quote/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\QuoteController@create',
        'controller' => 'App\\Http\\Controllers\\QuoteController@create',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.quote.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.quote.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/quote/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\QuoteController@store',
        'controller' => 'App\\Http\\Controllers\\QuoteController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.quote.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.quote.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/quote/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\QuoteController@edit',
        'controller' => 'App\\Http\\Controllers\\QuoteController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.quote.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.quote.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/quote/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\QuoteController@update',
        'controller' => 'App\\Http\\Controllers\\QuoteController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.quote.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.quote.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/quote/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\QuoteController@destroy',
        'controller' => 'App\\Http\\Controllers\\QuoteController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.quote.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.quote.cancel' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/quote/{id}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\QuoteController@cancel',
        'controller' => 'App\\Http\\Controllers\\QuoteController@cancel',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.quote.cancel',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.quote.duplicate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/quote/{id}/duplicate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\QuoteController@duplicate',
        'controller' => 'App\\Http\\Controllers\\QuoteController@duplicate',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.quote.duplicate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.quote.pdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/quote/{id}/pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\QuoteController@pdf',
        'controller' => 'App\\Http\\Controllers\\QuoteController@pdf',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.quote.pdf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity_payments' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/activity_payments/{activity_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityPaymentController@index',
        'controller' => 'App\\Http\\Controllers\\ActivityPaymentController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity_payments',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity_payment.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/activity_payment/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityPaymentController@show',
        'controller' => 'App\\Http\\Controllers\\ActivityPaymentController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity_payment.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity_payment.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/activity_payment/{activity_id}/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityPaymentController@create',
        'controller' => 'App\\Http\\Controllers\\ActivityPaymentController@create',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity_payment.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity_payment.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/activity_payment/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityPaymentController@store',
        'controller' => 'App\\Http\\Controllers\\ActivityPaymentController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity_payment.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity_payment.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/activity_payment/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityPaymentController@edit',
        'controller' => 'App\\Http\\Controllers\\ActivityPaymentController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity_payment.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity_payment.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/activity_payment/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityPaymentController@update',
        'controller' => 'App\\Http\\Controllers\\ActivityPaymentController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity_payment.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.activity_payment.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/activity_payment/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ActivityPaymentController@destroy',
        'controller' => 'App\\Http\\Controllers\\ActivityPaymentController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.activity_payment.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.delivery_orders' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/delivery_orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DeliveryOrderController@index',
        'controller' => 'App\\Http\\Controllers\\DeliveryOrderController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.delivery_orders',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.delivery_orders.purchase_order' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/delivery_orders/{id}/purchase_order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DeliveryOrderController@index',
        'controller' => 'App\\Http\\Controllers\\DeliveryOrderController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.delivery_orders.purchase_order',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.delivery_order.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/delivery_order/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DeliveryOrderController@show',
        'controller' => 'App\\Http\\Controllers\\DeliveryOrderController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.delivery_order.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.delivery_order.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/delivery_order/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DeliveryOrderController@create',
        'controller' => 'App\\Http\\Controllers\\DeliveryOrderController@create',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.delivery_order.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.delivery_order.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/delivery_order/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DeliveryOrderController@store',
        'controller' => 'App\\Http\\Controllers\\DeliveryOrderController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.delivery_order.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.delivery_order.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/delivery_order/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DeliveryOrderController@edit',
        'controller' => 'App\\Http\\Controllers\\DeliveryOrderController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.delivery_order.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.delivery_order.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/delivery_order/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DeliveryOrderController@update',
        'controller' => 'App\\Http\\Controllers\\DeliveryOrderController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.delivery_order.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.delivery_order.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/delivery_order/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DeliveryOrderController@destroy',
        'controller' => 'App\\Http\\Controllers\\DeliveryOrderController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.delivery_order.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.delivery_order.duplicate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/delivery_order/{id}/duplicate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DeliveryOrderController@duplicate',
        'controller' => 'App\\Http\\Controllers\\DeliveryOrderController@duplicate',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.delivery_order.duplicate',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_orders' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseOrderController@index',
        'controller' => 'App\\Http\\Controllers\\PurchaseOrderController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_orders',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_order.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_order/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseOrderController@show',
        'controller' => 'App\\Http\\Controllers\\PurchaseOrderController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_order.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_order.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_order/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseOrderController@create',
        'controller' => 'App\\Http\\Controllers\\PurchaseOrderController@create',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_order.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_order.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/purchase_order/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseOrderController@store',
        'controller' => 'App\\Http\\Controllers\\PurchaseOrderController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_order.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_order.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_order/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseOrderController@edit',
        'controller' => 'App\\Http\\Controllers\\PurchaseOrderController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_order.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_order.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/purchase_order/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseOrderController@update',
        'controller' => 'App\\Http\\Controllers\\PurchaseOrderController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_order.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_order.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/purchase_order/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseOrderController@destroy',
        'controller' => 'App\\Http\\Controllers\\PurchaseOrderController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_order.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.purchase_order.pdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase_order/{id}/pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseOrderController@pdf',
        'controller' => 'App\\Http\\Controllers\\PurchaseOrderController@pdf',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.purchase_order.pdf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.delivery_order.convert_po_to_do' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/purchase-order-to-delivery-order/{id}/convert',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PurchaseOrderController@convert_po_to_do',
        'controller' => 'App\\Http\\Controllers\\PurchaseOrderController@convert_po_to_do',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.delivery_order.convert_po_to_do',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.patients' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/patients',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PatientController@index',
        'controller' => 'App\\Http\\Controllers\\PatientController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.patients',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.patient.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/patient/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PatientController@show',
        'controller' => 'App\\Http\\Controllers\\PatientController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.patient.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.patient.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/patient/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PatientController@create',
        'controller' => 'App\\Http\\Controllers\\PatientController@create',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.patient.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.patient.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/patient/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PatientController@store',
        'controller' => 'App\\Http\\Controllers\\PatientController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.patient.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.patient.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/patient/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PatientController@edit',
        'controller' => 'App\\Http\\Controllers\\PatientController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.patient.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.patient.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/patient/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PatientController@update',
        'controller' => 'App\\Http\\Controllers\\PatientController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.patient.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.patient.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/patient/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PatientController@destroy',
        'controller' => 'App\\Http\\Controllers\\PatientController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.patient.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.appointments' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/appointments/{from}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@index',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.appointments',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.appointments.dates.filter' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/appointments/{from}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@index',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.appointments.dates.filter',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.calendar' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/calendar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@calendar',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@calendar',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.calendar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.appointment.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/appointment/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@show',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.appointment.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.appointment.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/appointment/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@create',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@create',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.appointment.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.appointment.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/appointment/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@store',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.appointment.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.appointment.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/appointment/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@edit',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.appointment.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.appointment.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/appointment/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@update',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.appointment.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.appointment.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/appointment/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@destroy',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.appointment.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.appointment.drop_or_resize' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'administrator/appointment/{id}/drop-or-resize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@dropOrResize',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@dropOrResize',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.appointment.drop_or_resize',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.status' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\StatusController@index',
        'controller' => 'App\\Http\\Controllers\\StatusController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.status',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.status.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/status/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\StatusController@show',
        'controller' => 'App\\Http\\Controllers\\StatusController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.status.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.status.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/status/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\StatusController@store',
        'controller' => 'App\\Http\\Controllers\\StatusController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.status.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.status.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/status/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\StatusController@edit',
        'controller' => 'App\\Http\\Controllers\\StatusController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.status.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.status.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/status/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\StatusController@update',
        'controller' => 'App\\Http\\Controllers\\StatusController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.status.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.status.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/status/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\StatusController@destroy',
        'controller' => 'App\\Http\\Controllers\\StatusController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.status.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.drugs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/drugs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DrugController@index',
        'controller' => 'App\\Http\\Controllers\\DrugController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.drugs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.drug.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/drug/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DrugController@show',
        'controller' => 'App\\Http\\Controllers\\DrugController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.drug.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.drug.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/drug/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DrugController@store',
        'controller' => 'App\\Http\\Controllers\\DrugController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.drug.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.drug.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/drug/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DrugController@edit',
        'controller' => 'App\\Http\\Controllers\\DrugController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.drug.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.drug.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/drug/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DrugController@update',
        'controller' => 'App\\Http\\Controllers\\DrugController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.drug.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.drug.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/drug/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\DrugController@destroy',
        'controller' => 'App\\Http\\Controllers\\DrugController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.drug.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.tests' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/tests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\TestController@index',
        'controller' => 'App\\Http\\Controllers\\TestController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.tests',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.test.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/test/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\TestController@show',
        'controller' => 'App\\Http\\Controllers\\TestController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.test.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.test.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/test/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\TestController@store',
        'controller' => 'App\\Http\\Controllers\\TestController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.test.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.test.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/test/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\TestController@edit',
        'controller' => 'App\\Http\\Controllers\\TestController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.test.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.test.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/test/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\TestController@update',
        'controller' => 'App\\Http\\Controllers\\TestController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.test.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.test.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/test/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\TestController@destroy',
        'controller' => 'App\\Http\\Controllers\\TestController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.test.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.type_drugs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/type_drugs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\TypeDrugController@index',
        'controller' => 'App\\Http\\Controllers\\TypeDrugController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.type_drugs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.type_drug.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/type_drug/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\TypeDrugController@show',
        'controller' => 'App\\Http\\Controllers\\TypeDrugController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.type_drug.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.type_drug.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/type_drug/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\TypeDrugController@store',
        'controller' => 'App\\Http\\Controllers\\TypeDrugController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.type_drug.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.type_drug.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/type_drug/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\TypeDrugController@edit',
        'controller' => 'App\\Http\\Controllers\\TypeDrugController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.type_drug.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.type_drug.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/type_drug/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\TypeDrugController@update',
        'controller' => 'App\\Http\\Controllers\\TypeDrugController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.type_drug.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.type_drug.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/type_drug/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\TypeDrugController@destroy',
        'controller' => 'App\\Http\\Controllers\\TypeDrugController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.type_drug.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.prescriptions' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/prescriptions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PrescriptionController@index',
        'controller' => 'App\\Http\\Controllers\\PrescriptionController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.prescriptions',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.prescription.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/prescription/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PrescriptionController@show',
        'controller' => 'App\\Http\\Controllers\\PrescriptionController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.prescription.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.prescription.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/prescription/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PrescriptionController@create',
        'controller' => 'App\\Http\\Controllers\\PrescriptionController@create',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.prescription.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.prescription.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/prescription/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PrescriptionController@store',
        'controller' => 'App\\Http\\Controllers\\PrescriptionController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.prescription.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.prescription.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/prescription/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PrescriptionController@edit',
        'controller' => 'App\\Http\\Controllers\\PrescriptionController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.prescription.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.prescription.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/prescription/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PrescriptionController@update',
        'controller' => 'App\\Http\\Controllers\\PrescriptionController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.prescription.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.prescription.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/prescription/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PrescriptionController@destroy',
        'controller' => 'App\\Http\\Controllers\\PrescriptionController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.prescription.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.prescription.pdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/prescription/{id}/pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\PrescriptionController@pdf',
        'controller' => 'App\\Http\\Controllers\\PrescriptionController@pdf',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.prescription.pdf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.charges' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/charges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ChargeController@index',
        'controller' => 'App\\Http\\Controllers\\ChargeController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.charges',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.charges.dates.filter' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/charges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ChargeController@index',
        'controller' => 'App\\Http\\Controllers\\ChargeController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.charges.dates.filter',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.charges.secretary' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/charges/{secretary_id}/secretary',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ChargeController@index',
        'controller' => 'App\\Http\\Controllers\\ChargeController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.charges.secretary',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.charges.secretary.dates.filter' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/charges/{secretary_id}/secretary',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ChargeController@index',
        'controller' => 'App\\Http\\Controllers\\ChargeController@index',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.charges.secretary.dates.filter',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.charge.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/charge/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ChargeController@show',
        'controller' => 'App\\Http\\Controllers\\ChargeController@show',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.charge.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.charge.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'administrator/charge/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ChargeController@store',
        'controller' => 'App\\Http\\Controllers\\ChargeController@store',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.charge.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.charge.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'administrator/charge/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ChargeController@edit',
        'controller' => 'App\\Http\\Controllers\\ChargeController@edit',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.charge.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.charge.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'administrator/charge/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ChargeController@update',
        'controller' => 'App\\Http\\Controllers\\ChargeController@update',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.charge.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'administrator.charge.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'administrator/charge/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.administrator',
        ),
        'uses' => 'App\\Http\\Controllers\\ChargeController@destroy',
        'controller' => 'App\\Http\\Controllers\\ChargeController@destroy',
        'namespace' => NULL,
        'prefix' => '/administrator',
        'where' => 
        array (
        ),
        'as' => 'administrator.charge.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'secretary/home',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\HomeController@index',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.password.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'secretary/edit-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@editPassword',
        'controller' => 'App\\Http\\Controllers\\UserController@editPassword',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.password.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.password.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'secretary/update-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@updatePassword',
        'controller' => 'App\\Http\\Controllers\\UserController@updatePassword',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.profile.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'secretary/edit-profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@editProfile',
        'controller' => 'App\\Http\\Controllers\\UserController@editProfile',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.profile.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.profile.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'secretary/update-profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@updateProfile',
        'controller' => 'App\\Http\\Controllers\\UserController@updateProfile',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.profile.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.patients' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'secretary/patients',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\PatientController@index',
        'controller' => 'App\\Http\\Controllers\\PatientController@index',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.patients',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.patient.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'secretary/patient/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\PatientController@show',
        'controller' => 'App\\Http\\Controllers\\PatientController@show',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.patient.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.patient.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'secretary/patient/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\PatientController@create',
        'controller' => 'App\\Http\\Controllers\\PatientController@create',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.patient.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.patient.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'secretary/patient/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\PatientController@store',
        'controller' => 'App\\Http\\Controllers\\PatientController@store',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.patient.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.patient.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'secretary/patient/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\PatientController@edit',
        'controller' => 'App\\Http\\Controllers\\PatientController@edit',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.patient.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.patient.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'secretary/patient/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\PatientController@update',
        'controller' => 'App\\Http\\Controllers\\PatientController@update',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.patient.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.patient.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'secretary/patient/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\PatientController@destroy',
        'controller' => 'App\\Http\\Controllers\\PatientController@destroy',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.patient.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.appointments' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'secretary/appointments/{from}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@index',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@index',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.appointments',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.calendar' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'secretary/calendar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@calendar',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@calendar',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.calendar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.appointment.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'secretary/appointment/{id}/show',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@show',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@show',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.appointment.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.appointment.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'secretary/appointment/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@create',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@create',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.appointment.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.appointment.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'secretary/appointment/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@store',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@store',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.appointment.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.appointment.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'secretary/appointment/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@edit',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@edit',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.appointment.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.appointment.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'secretary/appointment/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@update',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@update',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.appointment.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.appointment.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'secretary/appointment/{id}/destroy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@destroy',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@destroy',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.appointment.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'secretary.appointment.drop_or_resize' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'secretary/appointment/{id}/drop-or-resize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
          2 => 'prevent.back.history',
          3 => 'is.secretary',
        ),
        'uses' => 'App\\Http\\Controllers\\AppointmentController@dropOrResize',
        'controller' => 'App\\Http\\Controllers\\AppointmentController@dropOrResize',
        'namespace' => NULL,
        'prefix' => '/secretary',
        'where' => 
        array (
        ),
        'as' => 'secretary.appointment.drop_or_resize',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uCSxDadXDsoA56wj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{fallbackPlaceholder}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'language',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:266:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:48:"function(){
        return \\view(\'error\');
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000058ad94ba000000005b730e1b";}";s:4:"hash";s:44:"Om+KM1R9RDc4hKa8ahkYSFKtbKcbiZr6soNpySZnoaY=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::uCSxDadXDsoA56wj',
      ),
      'fallback' => true,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'fallbackPlaceholder' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
