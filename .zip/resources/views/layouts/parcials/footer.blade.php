<footer class="footer text-center">
            © 2022 {{__('messages.hospital_management')}} by <a href="https://www.devanas.com">www.devanas.com</a>
</footer>