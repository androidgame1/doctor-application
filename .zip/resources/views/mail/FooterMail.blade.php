<div class="footer-mail text-center">
                <a style="color:white" href="https://www.deliverypackage.com" class="link-mail">www.clinicmanagement.com</a>
            </div>