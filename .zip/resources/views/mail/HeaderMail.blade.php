<div class="header-mail">
                <img src="{{asset('assets/images/logo-text.png')}}" alt="">
            </div>